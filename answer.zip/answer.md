# 第1次作業-作業-作業1
>
>學號：111111203
><br />
>姓名：張紋綺
><br />
>作業撰寫時間：25 (mins，包含程式撰寫時間)
><br />
>最後撰寫文件日期：2023/10/19
>

本份文件包含以下主題：(至少需下面兩項，若是有多者可以自行新增)
- [x] 說明內容
- [x] 個人認為完成作業須具備觀念

## 說明程式與內容

1.git clone git@github.com/qqgatwe/111-2PC1 2.新增一個檔案A.txt並輸入This is an apple. 3.git commit 4.git push推送 5.git pull 6.檢視 命令選擇區 git log 7.git branch testdev 8.git checkout testdev 9.新增一個檔案B.txt並輸入This is a bear 10.git commit 11.git push推送 12.git pull 13.git checkout切換至main分支 14.新增一個檔案B.txt並輸入This is a cake. 15.git commit 16.git push推送 17.在main分支上把git merge testdev合併內容 18.git commit 19.git push推送

## 個人認為完成作業須具備觀念

GitHub使得代碼開發和協作變得更容易，有助於提高團隊協作和軟體開發的效率，這次作業運用到的指令除了git commit提交、git push推送和git pull拉取最新資料之外，還有學到合併分支git merge，將目前所在的分支與指定的分支合併在一起，合併的過程中可能對同一檔案內的內容修改且合併是會有覆蓋問題，git也會提示發生衝突，以便進行解決，學習到了很多呢。